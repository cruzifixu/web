<?php

$Servername = "localhost";
$Serveruser = "bif2webscriptinguser";
$Serverpwd = "bif2021";
$Dbname = "bif2webscriptinguser";

?>